from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from testapp1.models import Question

class SignupForm(UserCreationForm):
    class Meta:
        model=User
        fields=['username','email']

class QuestionForm(forms.ModelForm):
    class Meta:
        model=Question
        fields=['question','opt1','opt2','opt3','opt4']
