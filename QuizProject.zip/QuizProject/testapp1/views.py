from django.shortcuts import render
'''from testapp1.forms import AddForm'''
'''from django.contrib.sessions.models import Session'''
from django.contrib.auth.decorators import login_required
from testapp1.forms import SignupForm,QuestionForm
from testapp1.models import Question,result

# Create your views here.
def main_v(request):
    return render(request,'testapp1/main.html')



@login_required
def quiz_view(request):
    return render(request,'testapp1/quiz.html')

def logout_view(request):
    return render(request,'testapp1/logout.html')

def signup_view(request):
    form=SignupForm()
    return render(request,'testapp1/signup.html',{'form':form})

@login_required
def Create(request):
    que=QuestionForm()
    if request.method=='POST':
        que=QuestionForm(request.POST)
        if que.is_valid():
            que.save()
    return render(request,'testapp1/create.html',{'que':que})

def Attend_Exam(request):
    exam=Question.objects.all()
    count=10

    return render(request,'testapp1/exam.html',{'exam':exam,'count':count})

def result(request):
    total_marks=4
    question=Question.objects.all()

    for i in range(len(question)):
        selected_ans=request.COOKIES.get(i+1)
        actual_answer=question[i]
        if selected_ans == actual_answer:
            total_marks=total_marks + questions[i]


    
    #calculate()
    print('calculate complate')
    return render(request,'testapp1/result.html',{'total':total_marks})
