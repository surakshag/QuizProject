from django.db import models
from django.urls import reverse

# Create your models here.

class Question(models.Model):
    count=models.IntegerField(default=0)
    marks=models.PositiveIntegerField(default=0)

    question=models.CharField(max_length=500)
    opt1=models.CharField(max_length=100)
    opt2=models.CharField(max_length=100)
    opt3=models.CharField(max_length=100)
    opt4=models.CharField(max_length=100)
    select=(('opt1','opt1'),('opt2','opt2'),('opt3','opt3'),('opt4','opt4'))
    answer=models.CharField(max_length=100,choices=select)

class result(models.Model):
    marks=models.IntegerField()
    exam=models.CharField(max_length=500)
    student=models.CharField(max_length=500)
