from django.contrib import admin
from testapp1.models import Question

# Register your models here.
class QuestionAdmin(admin.ModelAdmin):
    list_display=['question','opt1','opt2','opt3','opt4']
admin.site.register(Question,QuestionAdmin)
